## Put comments here that give an overall description of what your
## functions do

## Write a short comment describing this function

B <- matrix(c(1,2,3,4),2,2)
#We pretend that this cant't happen xD

## Write a short comment describing this function
B1 <- makeCacheMatrix(B)
cacheSolve(B1) #inverse returned after computation
cacheSolve <- function(x, ...)

cacheSolve(B1)#inverse returned from cache